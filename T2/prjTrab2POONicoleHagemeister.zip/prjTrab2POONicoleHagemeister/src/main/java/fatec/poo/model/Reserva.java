/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fatec.poo.model;

/**
 *
 * @author Nicole
 */
public class Reserva {
    private int codigo;
    private String nomeHosp;
    private Data dataEntrada;
    private Data dataSaida;
    private double valorHosped;

    private Hotel hotel;

    public Reserva(int codigo, String nomeHosp, Data dataEntrada) {
        this.codigo = codigo;
        this.nomeHosp = nomeHosp;
        this.dataEntrada = dataEntrada;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNomeHospede() {
        return nomeHosp;
    }

    public Data getDataEntrada() {
        return dataEntrada;
    }

    public Data getDataSaida() {
        return dataSaida;
    }

    public double getValorHosped() {
        return valorHosped;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public double encerrarReserva(Data dataSaida) {

        this.dataSaida = dataSaida;

        int diasHospedado = dataSaida.subtrairDatas(dataEntrada);

        if (diasHospedado == 0) {
            diasHospedado = 1;
        }

        valorHosped = diasHospedado * hotel.getValorDiaria();

        hotel.addValorHospedagem(valorHosped);

        return valorHosped;
    }
}
