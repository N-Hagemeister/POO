/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fatec.poo.control;

import fatec.poo.model.Hotel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Nicole
 */
public class DaoHotel {
    private Connection conn;

    public DaoHotel(Connection conn) {
        this.conn = conn;
    }

    public Hotel consultar(int codigo) {
        Hotel objHot = null;

        PreparedStatement ps;

        try {
            ps = conn.prepareStatement(
                "SELECT * FROM tblHotel WHERE Codigo_Hot = ?"
            );

            ps.setInt(1, codigo);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                objHot = new Hotel(
                    rs.getInt("Codigo_Hot"),
                    rs.getString("Nome_Hot")
                );

                objHot.setEndereco(rs.getString("Endereco_Hot"));
                objHot.setTelefone(rs.getString("Telefone_Hot"));
                objHot.setValorDiaria(rs.getDouble("ValorDiaria_Hot"));
            }

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }

        return objHot;
    }

    public void inserir(Hotel hotel) {
        PreparedStatement ps;

        try {
            ps = conn.prepareStatement(
                "INSERT INTO tblHotel " +
                "(Codigo_Hot, Nome_Hot, Endereco_Hot, Telefone_Hot, ValorDiaria_Hot, TotalFaturamento_Hot) " +
                "VALUES (?, ?, ?, ?, ?, ?)"
            );

            ps.setInt(1, hotel.getCodigo());
            ps.setString(2, hotel.getNome());
            ps.setString(3, hotel.getEndereco());
            ps.setString(4, hotel.getTelefone());
            ps.setDouble(5, hotel.getValorDiaria());

            // Como getTotalFaturamento() retorna String formatada,
            // inicia com 0 no banco.
            ps.setDouble(6, 0);

            ps.execute();

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }

    public void alterar(Hotel hotel) {
        PreparedStatement ps;

        try {
            ps = conn.prepareStatement(
                "UPDATE tblHotel SET " +
                "Nome_Hot = ?, " +
                "Endereco_Hot = ?, " +
                "Telefone_Hot = ?, " +
                "ValorDiaria_Hot = ? " +
                "WHERE Codigo_Hot = ?"
            );

            ps.setString(1, hotel.getNome());
            ps.setString(2, hotel.getEndereco());
            ps.setString(3, hotel.getTelefone());
            ps.setDouble(4, hotel.getValorDiaria());
            ps.setInt(5, hotel.getCodigo());

            ps.execute();

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }

    public void excluir(Hotel hotel) {
        PreparedStatement ps;

        try {
            ps = conn.prepareStatement(
                "DELETE FROM tblHotel WHERE Codigo_Hot = ?"
            );

            ps.setInt(1, hotel.getCodigo());

            ps.execute();

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }
}
