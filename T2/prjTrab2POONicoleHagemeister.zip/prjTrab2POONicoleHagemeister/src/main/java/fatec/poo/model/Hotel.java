/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fatec.poo.model;

/**
 *
 * @author Nicole
 */
public class Hotel {
    private int codigo;
    private String nome;
    private String endereco;
    private String telefone;
    private double valorDiaria;
    private double totalFaturamento;

    public Hotel(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
        this.totalFaturamento = 0;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    public String getTotalFaturamento() {
        return String.format("R$ %.2f", totalFaturamento);
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setValorDiaria(double valorDiaria) {
        this.valorDiaria = valorDiaria;
    }

    public void addValorHospedagem(double valorHospedagem) {
        totalFaturamento += valorHospedagem;
    }
}
