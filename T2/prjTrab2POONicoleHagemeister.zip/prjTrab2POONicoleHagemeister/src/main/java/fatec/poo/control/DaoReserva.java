/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fatec.poo.control;

import fatec.poo.model.Data;
import fatec.poo.model.Hotel;
import fatec.poo.model.Reserva;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Nicole
 */
public class DaoReserva {    
      private Connection conn;

    public DaoReserva(Connection conn) {
        this.conn = conn;
    }

    public Reserva consultar(int codigo) {

        Reserva objRes = null;

        PreparedStatement ps;

        try {

            ps = conn.prepareStatement(
                    "SELECT * FROM tblReserva WHERE Codigo_Res = ?"
            );

            ps.setInt(1, codigo);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Data dataEntrada = new Data(
                        rs.getString("DataEntrada_Res")
                );

                objRes = new Reserva(
                        rs.getInt("Codigo_Res"),
                        rs.getString("NomeHosp_Res"),
                        dataEntrada
                );

                // Caso a reserva já tenha sido encerrada
                if (rs.getString("DataSaida_Res") != null) {

                    Data dataSaida = new Data(
                            rs.getString("DataSaida_Res")
                    );

                    objRes.encerrarReserva(dataSaida);
                }

                // Recupera o hotel associado
                DaoHotel daoHotel = new DaoHotel(conn);

                Hotel hotel = daoHotel.consultar(
                        rs.getInt("Codigo_Hot")
                );

                objRes.setHotel(hotel);
            }

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }

        return objRes;
    }

    public void inserir(Reserva reserva) {

        PreparedStatement ps;

        try {

            ps = conn.prepareStatement(
                    "INSERT INTO tblReserva "
                    + "(Codigo_Res, NomeHosp_Res, DataEntrada_Res, "
                    + "DataSaida_Res, ValorHosped_Res, Codigo_Hot) "
                    + "VALUES (?, ?, ?, ?, ?, ?)"
            );

            ps.setInt(1, reserva.getCodigo());
            ps.setString(2, reserva.getNomeHospede());
            ps.setString(3, reserva.getDataEntrada().toString());

            if (reserva.getDataSaida() == null) {
                ps.setString(4, null);
            } else {
                ps.setString(4, reserva.getDataSaida().toString());
            }

            ps.setDouble(5, reserva.getValorHosped());

            ps.setInt(6, reserva.getHotel().getCodigo());

            ps.execute();

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }

    public void alterar(Reserva reserva) {

        PreparedStatement ps;

        try {

            ps = conn.prepareStatement(
                    "UPDATE tblReserva SET "
                    + "NomeHosp_Res = ?, "
                    + "DataEntrada_Res = ?, "
                    + "DataSaida_Res = ?, "
                    + "ValorHosped_Res = ?, "
                    + "Codigo_Hot = ? "
                    + "WHERE Codigo_Res = ?"
            );

            ps.setString(1, reserva.getNomeHospede());
            ps.setString(2, reserva.getDataEntrada().toString());

            if (reserva.getDataSaida() == null) {
                ps.setString(3, null);
            } else {
                ps.setString(3, reserva.getDataSaida().toString());
            }

            ps.setDouble(4, reserva.getValorHosped());
            ps.setInt(5, reserva.getHotel().getCodigo());
            ps.setInt(6, reserva.getCodigo());

            ps.execute();

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }

    public void excluir(Reserva reserva) {

        PreparedStatement ps;

        try {

            ps = conn.prepareStatement(
                    "DELETE FROM tblReserva WHERE Codigo_Res = ?"
            );

            ps.setInt(1, reserva.getCodigo());

            ps.execute();

        } catch (SQLException ex) {
            System.out.println(ex.toString());
        }
    }
}
