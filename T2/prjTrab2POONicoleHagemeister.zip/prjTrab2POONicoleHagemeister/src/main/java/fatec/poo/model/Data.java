/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fatec.poo.model;

/**
 *
 * @author Nicole
 */
public class Data {
    private int dia;
    private int mes;
    private int ano;

    public Data(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    public int getDia() {
        return dia;
    }

    public int getMes() {
        return mes;
    }

    public int getAno() {
        return ano;
    }

    public String obterData() {
        return String.format("%02d/%02d/%04d", dia, mes, ano);
    }

    public double calcDiasCorridos() {
        int[] diasMeses = {31, 28, 31, 30, 31, 30,
                           31, 31, 30, 31, 30, 31};

        int somaMeses = 0;

        for (int i = 0; i < mes - 1; i++) {
            somaMeses += diasMeses[i];
        }

        if (ano % 4 == 0 && mes > 2) {
            somaMeses += 1;
        }

        return ((ano - 1) - 1900) * 365.25 + somaMeses + dia;
    }

    public int subtrairDatas(Data outraData) {
        return (int) Math.abs(
                this.calcDiasCorridos() - outraData.calcDiasCorridos()
        );
    }
}
